<?php
/*
   Plugin Name:Ajax Data Plugin 
   Version: 1.0.0
   Author: Prim Ncube
   Author URI: https:yellow-panda.co.za
   Description:Ajax example plugin
   Text Domain: Ajax example plugin
   License: GPLv3
*/


/*
This program is free software;you can redistribute in and/or modify it under
the terms of GNU General Public License as published by the free Software Foundation.

Copyright 2019-2020
*/

if ( ! defined( 'ABSPATH' ) ) {
  die;
}

class AssessmentTESTPlugin {
  //create methods

  function __construct(){
    add_action( 'init', array( 'AssessmentTESTPlugin', 'init' ) );
  }

  /*function register(){
    add_action('admin_enqueue_scripts', array($this, 'enqueue'));
  }*/
function activate(){
flush_rewrite_rules();
 }
function deactivate(){

 }
function unistall(){

 }

function custom_post_type() {
  register_post_type( 'book', ['public' => true, 'label' => 'Books'] );
 }
 //this label did not show on my wordpress dashboard

function enqueue(){
  wp_enqueue_style('mypluginstyle', plugins_url('/assets/style.css', __FILE__ ) );
}

}

if( class_exists('AssessmentTESTPlugin ') ) {

  $Testplugin = new AssessmentTESTPlugin('');
}
//activate
register_activation_hook( __FILE__, array( $Testplugin,'activate') );

//deactivate
register_deactivation_hook( __FILE__, array( $Testplugin,'deactivate') );

//uninstall
register_uninstall_hook( __FILE__, array( $Testplugin,'uninstall') );



?>
